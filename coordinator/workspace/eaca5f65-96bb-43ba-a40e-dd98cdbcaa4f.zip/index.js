console.log("Hello from generated project!");
console.log("Prompt: create a to do web app
");
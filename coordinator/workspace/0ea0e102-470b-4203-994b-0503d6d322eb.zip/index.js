console.log("Hello from generated project!");
console.log("Prompt: hi");